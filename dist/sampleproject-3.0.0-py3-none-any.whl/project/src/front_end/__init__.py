__all__ = [
    "Searcher",
    "Results"
    ]
